# silk QEMU local emulator -- precompiled bundle

Everything needed to run the silk (Pebble 2) firmware locally, already
built -- no `waf`, no `python2`, no `arm-none-eabi-gcc` required.

## What's in here

```
pebble_link.py        -- the engine (launches QEMU, speaks PULSE2 to it)
pebble_emulator.py     -- the Tkinter GUI (live screen + buttons)
pebble_build.py        -- only needed if you want to rebuild from source later
python_libs/pulse2/    -- the PULSE2 protocol library the above two use
                           (vendored from the firmware repo, with the
                           Python-3 port fixes made this session)
build/
  qemu_micro_flash.bin -- precompiled internal flash image
  qemu_spi_flash.bin   -- precompiled external SPI flash image
  src/fw/tintin_fw.elf -- the firmware ELF (for gdb/addr2line/objdump,
                           not needed just to run the emulator)
```

## The one thing NOT included: QEMU itself

`qemu-system-arm` is an 85MB binary dynamically linked against SDL2,
GTK3, glib and a dozen other system libraries -- not something that
reliably runs on a different machine without being rebuilt there. You
need a local build of **coredevices/qemu** (the fork with the
`pebble-silk-bb` machine -- stock upstream QEMU doesn't have it):

```
git clone https://github.com/coredevices/qemu
cd qemu
# follow its own build instructions (needs ninja, the usual QEMU build deps)
./configure --target-list=arm-softmmu
ninja -C build
```

That gives you `build/qemu-system-arm` -- point `pebble_emulator.py` at it
with `--qemu`, or put it at `~/coredevices/qemu/build/qemu-system-arm`
(the default it looks for).

## Setup

```
pip3 install pyserial construct==2.5.3 transitions pillow cobs
```

Note on `construct`: only the old ("2.5.x") API works with the vendored
pulse2 library here -- modern construct (2.9+) renamed it entirely. If
`pip install construct==2.5.3` won't build on your Python version (it's
an old pure-Python package with a deprecated `setup.py`), download the
sdist from PyPI, extract it, and set
`PULSE2_CONSTRUCT_PATH=/path/to/construct-2.5.3` when running the
emulator instead -- it gets added to `sys.path` automatically.

`tkinter` is usually bundled with python3; on Debian/Ubuntu if it's
missing: `sudo apt install python3-tk`.

## Run it

```
python3 pebble_emulator.py --repo . --qemu /path/to/qemu-system-arm
```

(`--repo .` -- run this from inside the extracted bundle folder, since
that's where `build/qemu_micro_flash.bin` etc. live.)

Boot takes ~15-20 seconds; the status line at the top tracks progress.
Click Back/Up/Select/Down with the mouse, or use Esc/arrow keys/Enter.

## If you want to rebuild from source instead

Clone the full repo (`https://github.com/IEI-Inc/silkulator`), which has
the complete source tree plus these same tools under
`tools/local_qemu_emulator/`, and run `pebble_build.py` there (needs
python2 + arm-none-eabi-gcc, see that copy's own README for details).
The `build/` images here are a snapshot of that build -- rebuilding gets
you the same thing plus the ability to change the firmware itself.

## Known quirk

The SPI flash image carries boot-state across runs (same as a real
device's external flash would), so the firmware's "Your Pebble just
reset" dialog can appear on first boot -- the emulator dismisses it
automatically with one BACK click before the GUI takes over.

This is a from-scratch reconstruction of files Google's public dump
omitted, not stock production firmware. Some UI paths can still hang
(pressing Down repeatedly deep into the Settings list, for one) -- if a
click times out the status line says so and the view keeps polling; it
isn't a bug in this tool.
